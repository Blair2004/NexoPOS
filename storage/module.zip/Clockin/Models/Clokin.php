<?php
namespace Modules\Clockin\Models;

use Illuminate\Database\Eloquent\Model;

class Clockin extends Model
{
    protected $table = 'clockin_timer';
}